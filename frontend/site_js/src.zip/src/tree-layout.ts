
class Tree {
  width: number;
  height: number;
  x: number = 0.0;
  y: number = 0.0;
  initialX: number = 0.0;
  modifierX: number = 0.0;
  shiftX: number = 0.0;
  posChange: number = 0.0;
  threadLeft: Tree = new Tree(0, 0, 0);
  threadRight: Tree = new Tree(0, 0, 0);
  extremeLeft: Tree = new Tree(0, 0, 0);
  extremeRight: Tree = new Tree(0, 0, 0);
  modSumLeft: number = 0.0;
  modSumRight: number = 0.0;
  children: Tree[];

  constructor(w: number, h: number, y: number, ...c: Tree[]) {
    this.width = w;
    this.height = h;
    this.y = y;
    this.children = c;
  }
}

function layout(tree: Tree): void {
  firstWalk(tree);
  secondWalk(tree, 0);
}

function firstWalk(tree: Tree): void {
  if (tree.children.length === 0) {
    setExtremes(tree);
    return;
  }
  firstWalk(tree.children[0]);
   
  let indexHighest = updateIndexYLowest(bottom(tree.children[0].extremeLeft), 0, null);
  for (let i = 1; i < tree.children.length; i++) {
    firstWalk(tree.children[i]);

    let minY = bottom(tree.children[i].extremeRight);
    separate(tree, i, indexHighest);
    indexHighest = updateIndexYLowest(minY, i, indexHighest);
  }
  positionRoot(tree);
  setExtremes(tree);
}

function setExtremes(tree: Tree): void {
  if (tree.children.length === 0) {
    tree.extremeLeft = tree;
    tree.extremeRight = tree;
    tree.modSumLeft = tree.modSumRight = 0;
  } else {
    tree.extremeLeft = tree.children[0].extremeLeft;
    tree.modSumLeft = tree.children[0].modSumLeft;
    tree.extremeRight = tree.children[tree.children.length - 1].extremeRight;
    tree.modSumRight = tree.children[tree.children.length - 1].modSumRight;
  }
}

function separate(tree: Tree, i: number, indexHighest: IndexYLowest): void {
  let subtreeRight = tree.children[i - 1];
  let modSumSubtreeRight = subtreeRight.modifierX;

  let contourLeft = tree.children[i];
  let modSumContourLeft = contourLeft.modifierX;
  while (subtreeRight && contourLeft) {
    if (bottom(subtreeRight) > indexHighest.lowY) {
      indexHighest = indexHighest.next;
    }

    let dist = (modSumSubtreeRight + subtreeRight.initialX + subtreeRight.width) - (modSumContourLeft + contourLeft.initialX);
    if (dist > 0) {
      modSumContourLeft += dist;
      moveSubtree(tree, i, indexHighest.index, dist);
    }
    let subtreeY = bottom(subtreeRight);
    let contourY = bottom(contourLeft);

    if (subtreeY <= contourY) {
      subtreeRight = nextRightContour(subtreeRight);
      if (subtreeRight) {
        modSumSubtreeRight += subtreeRight.modifierX;
      }
    }
    if (subtreeY >= contourY) {
      contourLeft = nextLeftContour(contourLeft);
      if (contourLeft) {
        modSumContourLeft += contourLeft.modifierX;
      }
    }
  }

  if (!subtreeRight && contourLeft) {
    setLeftThread(tree, i, contourLeft, modSumContourLeft);
  } else if (subtreeRight && !contourLeft) {
    setRightThread(tree, i, subtreeRight, modSumSubtreeRight);
  }
}


function moveSubtree(tree: Tree, i: number, sourceIndex: number, dist: number): void {
    
    tree.children[i].modifierX += dist;
    tree.children[i].modSumLeft += dist;
    tree.children[i].modSumRight += dist;
    distributeExtra(tree, i, sourceIndex, dist);
}

function nextLeftContour(tree: Tree): Tree {
    if (tree.children.length === 0) {
        return tree.threadLeft;
    } else {
        return tree.children[0];
    }
}

function nextRightContour(tree: Tree): Tree {
    if (tree.children.length === 0) {
        return tree.threadRight;
    } else {
        return tree.children[tree.children.length - 1];
    }
}

function bottom(tree: Tree): number {
    return tree.y + tree.height;
}

function setLeftThread(tree: Tree, i: number, contourLeft: Tree, modSumContourLeft: number): void {
    let leftIndex: Tree = tree.children[0].extremeLeft;
    leftIndex.threadLeft = contourLeft;
    
    let diff: number = (modSumContourLeft - contourLeft.modifierX);
    diff -= tree.children[0].modSumLeft;
    leftIndex.modifierX += diff;
    
    leftIndex.initialX -= diff;
    
    tree.children[0].extremeLeft = tree.children[i].extremeLeft;
    tree.children[0].modSumLeft = tree.children[i].modSumLeft;
}

function setRightThread(tree: Tree, i: number, subtreeRight: Tree, modSumSubtreeRight: number): void {
    let rightIndex: Tree = tree.children[i].extremeRight;
    rightIndex.threadRight = subtreeRight;
    let diff: number = (modSumSubtreeRight - subtreeRight.modifierX);
    diff -= tree.children[i].modSumRight;
    rightIndex.modifierX += diff;
    rightIndex.initialX -= diff;
    tree.children[i].extremeRight = tree.children[i - 1].extremeRight;
    tree.children[i].modSumRight = tree.children[i - 1].modSumRight;
}

function positionRoot(tree: Tree): void {
    
    tree.initialX = (tree.children[0].initialX +
        tree.children[0].modifierX +
        tree.children[tree.children.length - 1].modifierX +
        tree.children[tree.children.length - 1].initialX +
        tree.children[tree.children.length - 1].width) / 2 - tree.width / 2;
}

function secondWalk(tree: Tree, modSum: number): void {
    modSum += tree.modifierX;
    
    tree.x = tree.initialX + modSum;
    addChildSpacing(tree);
    for (let i = 0; i < tree.children.length; i++) {
        secondWalk(tree.children[i], modSum);
    }
}

function distributeExtra(tree: Tree, i: number, sourceIndex: number, dist: number): void {
    
    if (sourceIndex !== i - 1) {
        let numberRecipients: number = i - sourceIndex;
        tree.children[sourceIndex + 1].shiftX += dist / numberRecipients;
        tree.children[i].shiftX -= dist / numberRecipients;
        tree.children[i].posChange -= dist - dist / numberRecipients;
    }
}


function addChildSpacing(tree: Tree): void {
  let d = 0, modSumDelta = 0;
  for (let i = 0; i < tree.children.length; i++) {
    d += tree.children[i].shiftX;
    modSumDelta += d + tree.children[i].posChange;
    tree.children[i].modifierX += modSumDelta;
  }
}

class IndexYLowest {
  lowY: number;
  index: number;
  next: IndexYLowest;

  constructor(lowY: number, index: number, next: IndexYLowest) {
    this.lowY = lowY;
    this.index = index;
      this.next = next;
  }
}

function updateIndexYLowest(minY: number, i: number, indexHighest: IndexYLowest): IndexYLowest {
  while (indexHighest !== null && minY >= indexHighest.lowY) {
    indexHighest = indexHighest.next;
  }
  return new IndexYLowest(minY, i, indexHighest);
}

