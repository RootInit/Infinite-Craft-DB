

export function initializeCanvas(canvasElm) {
  // Set canvas size
  const canvas = new fabric.Canvas(canvasElm);
  // Set canvas style
  canvasElm.parentElement.style.width = "100%";
  canvasElm.parentElement.style.height = "100%";
  // Resize canvas with window
  function resizeCanvas() {
    let outerElement = canvasElm.parentElement.parentElement;
    let width = outerElement.offsetWidth;
    let height = window.innerHeight*.8;
    canvas.setDimensions({width: width, height: height});
    console.log(width, height)
    fitCanvasToObjects(canvas.getObjects());
  }
  resizeCanvas(); // run initially
  window.addEventListener('resize', resizeCanvas, false);
  // Add controls to canvas
  // Scroll zoom
  canvas.on('mouse:wheel', function(opt) {
    var delta = opt.e.deltaY;
    var zoom = canvas.getZoom();
    zoom *= 0.999 ** delta;
    if (zoom > 20) zoom = 20;
    if (zoom < 0.01) zoom = 0.01;
    canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
    opt.e.preventDefault();
    opt.e.stopPropagation();
  });

  // Click and drag pan
  canvas.on('mouse:down', function(opt) {
    var evt = opt.e;
    // If an object is clicked, don't pan
    var target = canvas.findTarget(evt, false); 
    if (target && target.eventable !== false) {
      return;
    }
    this.isDragging = true;
    this.selection = false;
    this.lastPosX = evt.clientX;
    this.lastPosY = evt.clientY;
  }
  );
  canvas.on('mouse:move', function(opt) {
    if (this.isDragging) {
      var e = opt.e;
      var vpt = this.viewportTransform;
      vpt[4] += e.clientX - this.lastPosX;
      vpt[5] += e.clientY - this.lastPosY;
      this.renderAll();
      this.lastPosX = e.clientX;
      this.lastPosY = e.clientY;
    }
  });
  canvas.on('mouse:up', function() {
    // on mouse up we want to recalculate new interaction
    // for all objects, so we call setViewportTransform
    this.setViewportTransform(this.viewportTransform);
    this.isDragging = false;
    this.selection = true;
  });
  return canvas;
}

// Function to return left, right, top, and bottom bounds
// of multiple canvas objects
export function findObjectBounds(objects) {
  let left = Math.min(...objects.map(o=>o.left-(o.width/2))); 
  let right = Math.max(...objects.map(o=>o.left+(o.width/2))); 
  let top = Math.min(...objects.map(o=>o.top-(o.height/2))); 
  let bottom = Math.max(...objects.map(o=>o.top+(o.height/2))); 
  return [left, right, top, bottom];
}


export function fitCanvasToObjects(objects) {
  const EDGESPACING = 30;
  if (objects.length === 0) {
    return; // No objects to fit too
  }
  const canvas = objects[0].canvas;
  var [objLeft, objRight, objTop, objBottom] = findObjectBounds(objects);
  // Add margin
  objLeft -= EDGESPACING;
  objRight += EDGESPACING;
  objTop -= EDGESPACING;
  objBottom += EDGESPACING;
  const objWidth = objRight-objLeft;
  const objHeight = objBottom-objTop;
  // Zoom to fit the items
  const scaleFactor = Math.min(canvas.width/objWidth, canvas.height/objHeight);
  canvas.setZoom(scaleFactor);
  // Center the viewport on the items
  const centerX = (objLeft + objRight) / 2;
  const centerY = (objTop + objBottom) / 2;
  canvas.viewportTransform = [scaleFactor, 0, 0, scaleFactor, canvas.width / 2 - centerX * scaleFactor, canvas.height / 2 - centerY * scaleFactor];
  // TODO is this needed?
  canvas.renderAll();
}


