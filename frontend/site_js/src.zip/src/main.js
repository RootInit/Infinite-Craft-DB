import {
  initializeCanvas,
  fitCanvasToObjects
} from "./canvas-utils";
import { newTree } from "./canvas-tree";

// const ROOTURL = "http://127.0.0.1:8081"
const ROOTURL = window.location.protocol + '//' + window.location.host;

// Handle crafting tree canvas
const canvasElm = document.getElementById('craftTreeView');
const canvas = initializeCanvas(canvasElm);
// Function resets canvas and displays an item tree
async function showCanvasRecipe(itemId) {
  canvas.clear();
  var treeData = await runRequest(`getItemRecipe?item=`+itemId)
  var rootNode = newTree(canvas, treeData);
  // Debug info
  treeData.forEach((node) => {
    console.log(node)
  });
  console.log(rootNode)
  //fitCanvasToObjects(canvas.getObjects());
  // TODO fix this broken
}
// Show initial random recipe
const randomRecipeId = Math.floor(Math.random() * 10000) + 5
showCanvasRecipe(randomRecipeId);

// TODO search

// Handle infinite scrolling item list
const itemListElm = document.getElementById('itemList');
var itemListLastId = 0;
async function loadNewItems() { 
  const itemsJson = await runRequest(`getNextItems?after=`+itemListLastId)
  if (itemsJson == null) {
    console.log("Empty response from getNextItems");
    return false;
  }
  itemListLastId = itemsJson[itemsJson.length-1]["ID"];
  // Add items to DOM
  itemsJson.forEach(item => {
    const itemElm = document.createElement('div');
    itemElm.textContent = item["Text"];
    itemElm.addEventListener('click', function() {
      // Enable scrollBack to previous height
      setScrollBackListener();
      // Show the recipe
      showCanvasRecipe(item["ID"]);
      // Scroll to recipe canvas
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
    itemListElm.appendChild(itemElm);
  });
  return true;
}
loadNewItems();
function handleInfinteScroll() {
  // Total scroll height
  const scrollHeight = window.innerHeight+window.scrollY;
  const bodyHeight = document.body.offsetHeight;
  // Load items when one full window height remains
  const loadHeight = bodyHeight-window.innerHeight;
  if (scrollHeight >= loadHeight) {
    let result = loadNewItems();
    if (result === false) {
      // Loaded all the items
      window.removeEventListener('scroll', handleInfinteScroll);
    }
  }
}
window.addEventListener('scroll', handleInfinteScroll);

// Scroll back listener to return to original
// place on item list
function setScrollBackListener() {
  const initialScrollY = window.scrollY;
  var lastScrollY = initialScrollY;
  const scrollBack = function() {
    const currentScrollY = window.scrollY;
    if (currentScrollY > lastScrollY) {
      window.removeEventListener('scroll', scrollBack);
        window.scrollTo({
          top: initialScrollY,
          // TODO make work with behavior: 'smooth'
        });
    }
    lastScrollY = currentScrollY;
  }
  window.addEventListener('scroll', scrollBack);
}

async function runRequest(request) {
  try {
    const url = ROOTURL + `/api/` + request;
    const response = await fetch(url);
    if (response.ok) {
      return await response.json();
    } else if (response.status === 429) {
      window.alert("Too Many Requests. Please try again later.");
      console.error("Request failed. Too many requests.");
    } else {
      console.error("Request failed. Status: "+response.status);
    }
  } catch (error) {
    console.error("Error:", error);
    return null
  }
}
