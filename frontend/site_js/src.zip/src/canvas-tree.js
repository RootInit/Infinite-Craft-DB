import { fabric } from "fabric";
import { layout } from "tree-layout";

const ITEMPADDING = 10
const RADIUS = 5
const ROWSPACING = 75
const COLSPACING = 30

export function newTree(canvas, treeData) {
  // Find the root item
  const rootItemIndex = treeData.findIndex(item => item.length === 2);
  if (rootItemIndex === -1) {
    throw new Error("Root item not found in array.")
  } 
  const rootItemData = treeData.splice(rootItemIndex, 1)[0];
  const rootNode = new TreeNode(
    createTreeCanvasItem(canvas, rootItemData[0], rootItemData[1])
  );
  // Recursive function to add children to the tree data structure 
  function addChildren(rootItem, rootItemId) {
    treeData.forEach((item) => {
      if (item[2] === rootItemId) {
        let child = rootItem.addChild(
          createTreeCanvasItem(canvas, item[0], item[1])
        );
        treeData = treeData.filter(i => i!==item)
        addChildren(child, item[0]);
      }
    });
    rootItem.canvasItem.on('mousedown', function () {
      rootItem.toggleChildVisability(); 
    });
  }
  addChildren(rootNode, rootItemData[0]);
  // Check for left over rows
  treeData.forEach((item) => {
    console.warn("Orphaned tree item: " + item);
  })
  // Align nodes and draw connector lines
  rootNode.alignNodes();
  rootNode.drawChildLines();
  return rootNode;
}


// data-structure to store a tree of canvas objects
export class TreeNode {
  constructor(canvasItem) {
    this.canvasItem = canvasItem;
    this.parent = null;
    this.children = [];
    this.connectorLine = null;
    // Layout properties 
    this._width = this.canvasItem.width;
    this._height = this.canvasItem.Height;
    this._x = 0.0;
    this._y = this.canvasItem.top;
    this._initialX = 0.0;
    this._modifierX = 0.0;
    this._shiftX = 0.0;
    this._posChange = 0.0;
    this._threadLeft = null;
    this._threadRight = null;
    this._extremeLeft = null;
    this._extremeRight = null;
    this._modSumLeft = 0.0;
    this._modSumRight = 0.0;
  }
  layoutNodes() {
    layout(this);
  }
  getDepth(depth=0) {
    if (this.parent != null) {
      depth = this.parent.getNodeDepth(depth=1)
    }
    return depth;
  }
  getMaxDepth(fromBottom = 0) {
    let depths = this.children.map((child) => {
      return child.getMaxDepth(fromBottom + 1);
    });
    return depths.length > 0 ? Math.max(...depths) : fromBottom;
  }
  getNodesAtDepth(targetDepth, currentDepth = 0, result = []) {
    if (currentDepth === targetDepth) {
      result.push(this);
    } else {
      this.children.forEach((child) => {
        child.getNodesAtDepth(targetDepth, currentDepth + 1, result);
      });
    }
    return result;
  }
  addChild(canvasItem) {
    let itemNode = new TreeNode(canvasItem);
    itemNode.parent = this;
    this.children.push(itemNode);
    return itemNode;
  }
  shiftNode(dX, dY) {
    let canvasItem = this.canvasItem;
    canvasItem.set({
      left: canvasItem.left+dX,
      top: canvasItem.top+dY
    })
    this.children.forEach((child) => {
      child.shiftNode(dX, dY);
    });
  }
  setNodePos(posX, posY) {
    const dX = posX-this.canvasItem.left;
    const dY = posY-this.canvasItem.top;
    this.shiftNode(dX, dY);
  }
  toggleChildVisability(isTop=true) {
    if (!isTop) {
      this.canvasItem.visible = !this.canvasItem.visible;
      this.connectorLine.visible = !this.connectorLine.visible;
    }
    this.children.forEach((child) => {
      child.toggleChildVisability(false);
    });
  }
  drawLine() {

  }
  drawChildLines() {
    this.children.forEach((child) => {
      if (child.connectorLine != null) {
        child.canvasItem.canvas.remove(child.connectorLine);
      }
      let line = drawConnectorLine(this.canvasItem, child.canvasItem);
      child.connectorLine = line;
      child.drawChildLines();
    });
  }
}


/*
// data-structure to store a tree of canvas objects
export class TreeNodeOLD {
  constructor(canvasItem) {
    this.itemId = canvasItem.get("id"),
    this.canvasItem = canvasItem;
    this.parent = null;
    this.children = [];
    this.connectorLine = null;
  }
  alignNodes() {
    setNodePositions(this);
  }
  getNodeById(id) {
    var foundNode = null
    if (this.itemId == id) {
      foundNode = this;
    }
    this.children.forEach((node) => {
      foundNode=node.getById(id)
    });
    return foundNode; 
  }
  getMaxDepth(fromBottom = 0) {
    let depths = this.children.map((child) => {
      return child.getMaxDepth(fromBottom + 1);
    });
    return depths.length > 0 ? Math.max(...depths) : fromBottom;
  }
  getNodesAtDepth(targetDepth, currentDepth = 0, result = []) {
    if (currentDepth === targetDepth) {
      result.push(this);
    } else {
      this.children.forEach((child) => {
        child.getNodesAtDepth(targetDepth, currentDepth + 1, result);
      });
    }
    return result;
  }
  addChild(canvasItem) {
    let itemNode = new TreeNode(canvasItem);
    itemNode.parent = this;
    this.children.push(itemNode);
    return itemNode;
  }
  shiftNode(dX, dY) {
    let canvasItem = this.canvasItem;
    canvasItem.set({
      left: canvasItem.left+dX,
      top: canvasItem.top+dY
    })
    this.children.forEach((child) => {
      child.shiftNode(dX, dY);
    });
  }
  setNodePos(posX, posY) {
    const dX = posX-this.canvasItem.left;
    const dY = posY-this.canvasItem.top;
    this.shiftNode(dX, dY);
  }
  toggleChildVisability(isTop=true) {
    if (!isTop) {
      this.canvasItem.visible = !this.canvasItem.visible;
      this.connectorLine.visible = !this.connectorLine.visible;
    }
    this.children.forEach((child) => {
      child.toggleChildVisability(false);
    });
  }
  drawLine() {

  }
  drawChildLines() {
    this.children.forEach((child) => {
      if (child.connectorLine != null) {
        child.canvasItem.canvas.remove(child.connectorLine);
      }
      let line = drawConnectorLine(this.canvasItem, child.canvasItem);
      child.connectorLine = line;
      child.drawChildLines();
    });
  }
}
*/

// Draws a tree connector line from the bottom of
// the firstObject to the top of the secondItem
function drawConnectorLine(firstObject, secondItem) {
  const canvas = firstObject.canvas;
  // Calculate the start and end points 
  const startX = firstObject.left;
  const startY = firstObject.top+firstObject.height/2;
  const endX = secondItem.left;
  const endY = secondItem.top-secondItem.height/2;
  // Calculate midpoints
  const midY = startY+(endY-startY)/2;
  const midX1 = startX;
  const midX2 = endX;
  const line = new fabric.Polyline(
    [
      { x: startX, y: startY },
      { x: midX1, y: midY },
      { x: midX2, y: midY },
      { x: endX, y: endY },
    ],
    {
      stroke: 'black',
      strokeWidth: 1,
      fill: '', // Prevent closed shape
      evented: false,
    }
  );
  canvas.add(line);
  canvas.sendToBack(line);
  return line
}


function createTreeCanvasItem(canvas, id, text) {
  var text = new fabric.Text(text, {
    fontSize: 12,
    originX: 'center',
    originY: 'center',
    fill: '#000',
    fontFamily: 'Roboto, sans-serif', // Specify the sans-serif font family
  });
  const textBounds = text.getBoundingRect();
  const boxWidth = Math.round(textBounds.width + ITEMPADDING);
  const boxHeight = Math.round(textBounds.height + ITEMPADDING);
  var box = new fabric.Rect({
    fill: '#FFF',
    stroke: "#000",
    strokeWidth: 1,
    width: boxWidth,
    height: boxHeight,
    originX: 'center',
    originY: 'center',
    rx: RADIUS,
    ry: RADIUS
  });
  const group = new fabric.Group([box, text], {
    originX: 'center',
    originY: 'center',
    left: canvas.width/2,
    top: canvas.width/2,
    hasControls: false,
    lockMovementX: true,
    lockMovementY: true,
    id: id,
  });
  canvas.add(group);
  return group;
}

function setNodePositions(rootNode) {
  const contourLeft = [rootNode];
  drill(rootNode);
  function drill(subtree) {
    subtree.canvasItem.width = subtree.canvasItem.width;
    subtree.canvasItem.height = subtree.canvasItem.height;
    if (!subtree.children) return;

    let currentChildY = subtree.canvasItem.top + subtree.canvasItem.height + 2 * COLSPACING;
    let posX = 0, posY = 0;
    subtree.children.forEach((child, index) => {
      child.canvasItem.width = child.canvasItem.width;
      child.canvasItem.height = child.canvasItem.height;

      child.parent = subtree;
      if (index === 0) {
        const initialShiftLeft =
          subtree.children.reduce((totalWidth, child) => {
            totalWidth += (child.canvasItem.width) + 2 * COLSPACING;
            return totalWidth;
          }, 0) /
            2 -
            (subtree.canvasItem.width + 2 * COLSPACING) / 2;
        posX = subtree.canvasItem.left - initialShiftLeft;
      } else {
        const previousSibling = subtree.children[index - 1];
        posX = previousSibling.canvasItem.left + previousSibling.width + 2 * COLSPACING;
      }
      posY = currentChildY;
      child.setNodePos(posX, posY);

      const childLeftBorder = {
        x: child.canvasItem.left,
        topY: currentChildY,
        bottomY: currentChildY + child.canvasItem.height + 2 * COLSPACING,
      };
      //check if touches one of the contours
      contourLeft.forEach((contourNode) => {
        const contourRightBorder = {
          x: contourNode.canvasItem.left + contourNode.canvasItem.width + 2 * COLSPACING,
          topY: contourNode.canvasItem.top,
          bottomY: contourNode.canvasItem.top + contourNode.canvasItem.height + 2 * COLSPACING,
        };

        const childLeftBorderCovers =
          childLeftBorder.topY <= contourRightBorder.topY &&
            childLeftBorder.bottomY >= contourRightBorder.bottomY;

        if (
          contourRightBorder.x >= childLeftBorder.x &&
            ((childLeftBorder.topY > contourRightBorder.topY &&
              childLeftBorder.topY < contourRightBorder.bottomY) ||
              (childLeftBorder.bottomY > contourRightBorder.topY &&
                childLeftBorder.bottomY < contourRightBorder.bottomY) ||
              childLeftBorderCovers)
        ) {
          if (childLeftBorderCovers) {
            //todo: if it covers the whole box, remove box from contour
          }

          const delta = contourRightBorder.x - childLeftBorder.x;
          child.canvasItem.left += delta;
          childLeftBorder.x += delta;
        }
      });

      contourLeft.push(child);

      drill(child);
    });
    console.log(subtree)
    //put the parent in the middle of the children, when done
    if (subtree.children.lenth > 0) {
    const lasChild = subtree.children[subtree.children.length - 1];
    subtree.x =
      (subtree.children[0].canvasItem.left + lasChild.canvasItem.left + lasChild.canvasItem.width + 2 * COLSPACING) /
        2 -
        (subtree.canvasItem.width + 2 * COLSPACING) / 2;
  }
  }
}
/*
function setNodePositionsOLD(rootItem) {
  let originalX= rootItem.canvasItem.left;
  let originalY= rootItem.canvasItem.top;

  let yOffset = originalY;
  // Itterate through tree depth levels from bottom
  for (let d=rootItem.maxDepth;d>=0;d--) {
    let layer = rootItem.getNodesAtDepth(d);
    // Calculate layer width
    var xOffset = originalX;
    layer.forEach((node) => {
      let xPos = xOffset;
      if (node.children.length > 0) {
        // Center over children
        let childCanvasObjs = node.children.map(o => o.canvasItem);
        let [cLeft, cRight,,] = findCanvasObjectBounds(childCanvasObjs);
        xPos = cLeft+((cRight-cLeft)/2.0);
      } else {
        // Increment for next item 
        xOffset += node.canvasItem.width + COLSPACING;
      }
      node.canvasItem.set({
        left: xPos,
        top: yOffset,
      });
    });
    yOffset -= ROWSPACING;
  }
  // Move back to original location
  if (rootItem.left !== originalX || rootItem.right !== originalY) {
    let dX = (originalX-rootItem.canvasItem.left);
    let dY = (originalY-rootItem.canvasItem.top);
    rootItem.moveAll(dX, dY);
  }
}
*/
// ### Controlls ###
